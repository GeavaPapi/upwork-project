const Discord = require('discord.js-selfbot-v13')
const bot = new Discord.Client({ checkUpdate: false })
const fs = require('fs')
let bottoken = fs.readFileSync('token.txt', 'utf8');
let channels = fs.readFileSync('channels.txt', 'utf8');
if (bottoken.length < 5) return console.log('The Bot token is not valid')

bot.login(bottoken)

bot.on('ready', async () => {
    console.log(`The bot is logged as ${bot.user.tag}`)

})

bot.on('messageCreate', async (msg) => {
    let channels_array = channels.split(/\s+/)
    if (channels_array.includes(msg.channel.id)) {
        if(msg.embeds.length < 0){
        export_content(msg.content, msg.author.tag, msg.createdAt.toLocaleString(), msg.channel.name, "No Embeds Found")
        }else{
            export_content(msg.content, msg.author.tag, msg.createdAt.toLocaleString(), msg.channel.name, msg.embeds[0].description)
        }
    }
})

function export_content(messagecontent, messageauthor, messagedate, messagechannel, embeddescriptions) {

    console.log(`Message Content: ${messagecontent}\nMessage Author: ${messageauthor}\nMessage Date: ${messagedate}\nMessage Channel: ${messagechannel}\nMessage Embed Description: ${embeddescriptions}`)

}